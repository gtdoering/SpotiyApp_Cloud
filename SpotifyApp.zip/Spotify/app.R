#############################SpotifyR functions################################
#add_tracks_to_playlist                  html  
#change_playlist_details                 html  
#check_me_following                      html  
#check_users_following                   html  
#create_playlist                         html  
#dedupe_album_names                      html  
#follow_artists_or_users                 html  
#follow_playlist                         html  
#get_album                               html  
#get_album_data                          html  
#get_album_tracks                        html  
#get_albums                              html  
#get_artist                              html  
#get_artist_albums                       html  
#get_artist_audio_features               html  
#get_artist_top_tracks                   html  
#get_artists                             html  
#get_categories                          html  
#get_category                            html  
#get_category_playlists                  html  
#get_discography                         html  
#get_featured_playlists                  html  
#get_genre_artists                       html  
#get_label_artists                       html  
#get_my_current_playback                 html  
#get_my_currently_playing                html  
#get_my_devices                          html  
#get_my_followed_artists                 html  
#get_my_playlists                        html  
#get_my_profile                          html  
#get_my_recently_played                  html  
#get_my_saved_albums                     html  
#get_my_saved_tracks                     html  
#get_my_top_artists_or_tracks            html  
#get_new_releases                        html  
#get_playlist                            html  
#get_playlist_audio_features             html  
#get_playlist_cover_image                html  
#get_playlist_tracks                     html  
#get_recommendations                     html  
#get_recommendations_all                 html 
#get_related_artists                     html  
#get_spotify_access_token                html  
#get_spotify_authorization_code          html  
#get_track                               html  
#get_track_audio_analysis                html  
#get_track_audio_features                html  
#get_tracks                              html  
#get_user_audio_features                 html  
#get_user_playlists                      html  
#get_user_profile                        html  
#is_uri                                  html  
#pause_my_playback                       html  
#pitch_class_lookup                      html  
#print.playlist                          html  
#remove_tracks_from_playlist             html  
#scopes                                  html  
#search_spotify                          html  
#seek_to_position                        html  
#set_my_repeat_mode                      html  
#set_my_volume                           html  
#skip_my_playback                        html  
#skip_my_playback_previous               html  
#spotifyr                                html  
#start_my_playback                       html  
#tidy                                    html  
#toggle_my_shuffle                       html  
#transfer_my_playback                    html  
#unfollow_playlist                       html  
#verify_result                           html 

#installs the spotifyr library
devtools::install_github('charlie86/spotifyr')
library(spotifyr)

#Alllows for contact with spotify's web API
Sys.setenv(SPOTIFY_CLIENT_ID = '3e2ffc9154ba4bdf885282b6afab8e1a')
Sys.setenv(SPOTIFY_CLIENT_SECRET = '5325176284b34d2a9ab13ececac8a417')

access_token <- get_spotify_access_token()

#Loads the necesary library's
library(shiny)
library(shinyWidgets)
library(ggplot2)
library(plotly)
library(rstatix)
library(R.utils)
library(ggjoy)
library(dplyr)
library(stringr)
library(ggridges)


#Input for axis variables
names <- c("Acousticness","Danceability","Energy","Instrumentalness",
           "Liveness","Loudness",
           "Speechiness","Tempo","Valence")

#Initial Artist Data
data <- get_artist_audio_features("juice")

# Define UI for application that draws a histogram
ui <- fluidPage(
    
    setBackgroundColor("ghostwhite"),

    # Application title
    titlePanel("Spotify App"),

    # Sidebar with user interface controls and text 
    sidebarLayout(
        sidebarPanel(
            searchInput(
                inputId = "search", 
                label = "Enter an Artist Name to Search",
                placeholder = "ex. Juice WRLD",
                btnSearch = icon("search"),
                width = "450px"
            ),
            
            
            pickerInput(inputId = "picker",
                        label = "Choose an artist by Spotify Name or ID:", 
                        choices = NULL),
            
            
            h5(strong("Artist Image:")),
            htmlOutput('artist_img'),
            
            h5(strong("Top Track Preview:")),
            htmlOutput('song_preview'),
            
            selectInput("xaxis" , "X-Axis", choices= names, selected = 'Danceability'),
            selectInput("yaxis" , "Y-Axis", choices= names, selected = 'Valence'),
            h5(strong("(Scroll Down for Variable Explanations)"))
            
        ),

        # Show a plot of the generated distribution
        mainPanel(
            tabsetPanel(
           tabPanel("Artist Music Data",
                    h4(strong("Interactive Song Plot")),
                    plotlyOutput('plotly'),
                    h4(strong("Album Joy Plot")),
                    plotOutput('joy'),
                    h4(strong("Variable Defintions: ")),
                    p(strong("Acousticness: "), "A confidence measure from 0.0 to 1.0 of whether the track is 
              acoustic. 1.0 represents high confidence the track is acoustic. "),
                    p(strong("Danceability: "), "Danceability describes how suitable a track is for dancing based on 
              a combination of musical elements including tempo, rhythm stability, beat strength, 
              and overall regularity. A value of 0.0 is least danceable and 1.0 is most danceable. "),
                    p(strong("Energy: "), "Energy is a measure from 0.0 to 1.0 and represents a perceptual measure 
              of intensity and activity. Typically, energetic tracks feel fast, loud, and noisy. For 
              example, death metal has high energy, while a Bach prelude scores low on the scale. Perceptual 
              features contributing to this attribute include dynamic range, perceived loudness, timbre, 
              onset rate, and general entropy. "),
                    p(strong("Instrumentalness: "), "Predicts whether a track contains no vocals. “Ooh” and “aah” 
              sounds are treated as instrumental in this context. Rap or spoken word tracks are clearly 
              “vocal”. The closer the instrumentalness value is to 1.0, the greater likelihood the track 
              contains no vocal content. Values above 0.5 are intended to represent instrumental tracks, 
              but confidence is higher as the value approaches 1.0."),
                    p(strong("Liveness: "), "	Detects the presence of an audience in the recording. Higher 
              liveness values represent an increased probability that the track was performed live. 
              A value above 0.8 provides strong likelihood that the track is live."),
                    p(strong("Loudness: "), "The overall loudness of a track in decibels (dB). Loudness values are 
              averaged across the entire track and are useful for comparing relative loudness of tracks. 
              Loudness is the quality of a sound that is the primary psychological correlate of physical 
              strength (amplitude). Values typical range between -60 and 0 db."),
                    p(strong("Speechines: "),"Speechiness detects the presence of spoken words in a track. The more 
              exclusively speech-like the recording (e.g. talk show, audio book, poetry), the closer to 1.0 
              the attribute value. Values above 0.66 describe tracks that are probably made entirely of 
              spoken words. Values between 0.33 and 0.66 describe tracks that may contain both music and 
              speech, either in sections or layered, including such cases as rap music. Values below 0.33 
              most likely represent music and other non-speech-like tracks. "),
                    p(strong("Tempo: "), "The overall estimated tempo of a track in beats per minute (BPM). In 
              musical terminology, tempo is the speed or pace of a given piece and derives directly from
              the average beat duration."),
                    p(strong("Valence: "), "A measure from 0.0 to 1.0 describing the musical positiveness conveyed 
              by a track. Tracks with high valence sound more positive (e.g. happy, cheerful, euphoric), 
              while tracks with low valence sound more negative (e.g. sad, depressed, angry).")),
           tabPanel("Artist Top Tracks", tableOutput("top_tracks")),
           tabPanel("Artist Discography", tableOutput("discography")),
           tabPanel("Related Artists", tableOutput("relatedartists"))
            )
    )
)
)

# Define server logic required to draw a histogram
server <- function(input, output, session) {
    
    #Dropdown artist selection
    observeEvent(input$search, {
        #Rspotify
        possibleArtists <- search_spotify(input$search)
        possibleArtists <- possibleArtists$artists
        possibleArtists <- possibleArtists$items
        myCols <- c("name","id")
        colNums <- match(myCols,names(possibleArtists))
        possibleArtists <- possibleArtists %>%
            select(colNums)
        possibleArtists <- possibleArtists %>%
            rename(
                Spotify_Name = name,
                Spotify_ID = id
            )
        updatePickerInput(
            session = session,
            inputId = "picker",
            choices = possibleArtists
        )
    }, ignoreInit = TRUE)
    
    #Artist image and song preview
    observeEvent(input$picker, {
        #Artist image
        artist_info <- search_spotify(input$picker, 'artist')
        artist_name = input$picker
        artist_info <- artist_info %>% 
            filter(name == artist_name) %>% 
            filter(popularity == max(popularity))
        artist_img <- artist_info$images[[1]]$url[1]
        
        output$artist_img <- renderText({
            c('<center><img src="',artist_img,'" height = "200"></center>')
        })
        
        #Top song preview
        selected_artist <- get_artist_audio_features(input$picker)
        top_tracks <- get_artist_top_tracks(selected_artist$artist_id[1])
        
        best_song <- top_tracks$preview_url[[1]]
        
        if(!is.na(best_song)){
          output$song_preview <- renderText({
            c('<audio id="song_preview" src="',best_song,'" type = "audio/mp3" autoplay controls></audio>')
        })
        }else{
        output$song_preview <- renderText({
            '<center>No Preview Available</center>'
        })
        }
})
    
    #Generates interactive plotly from numeric variables
    output$plotly <- renderPlotly({
        req(input$picker != '')
        
        #generate artist data from search in ui.R and capitalize column names
        data <- get_artist_audio_features(input$picker)
        colnames(data) <- capitalize(colnames(data))
        
        #Set text size and set text for both axes
        f <- list(
            size = 18,
            color = "#7f7f7f"
        )
        x <- list(
            title = paste(input$xaxis),
            titlefont = f
        )
        #z <-  list(
        #    text = paste("Spotify data for", input$picker)
        #)
        y <- list(
            title = paste(input$yaxis),
            titlefont = f
        )
        
        #plot values for inputted variables
        fig <- plot_ly(data, x = ~get(input$xaxis), y = ~get(input$yaxis) , 
                       type = 'scatter', 
                       mode = 'markers',
                       color = ~Album_name,
                       hoverinfo = 'text',
                       text = ~paste('</br> Album: ', Album_name,
                                     '</br> Song: ', Track_name))
        fig <- fig %>% layout(xaxis = x, yaxis = y,
                              showlegend = FALSE)
        fig
        })
    
    #Generates a list of the Artist's Top Songs
    output$top_tracks <- renderTable({
        req(input$picker != '')
        
        data <- get_artist_audio_features(input$picker)
        top_tracks <- get_artist_top_tracks(data$artist_id[1])
    
        number1 <- top_tracks$name
        number2 <- top_tracks$album.name
        
        N_metrics <- matrix(c(number1, number2), ncol = 2)
        
        colnames(N_metrics) <- c("Track Name", "Album Name")
        row.names(N_metrics) <- c (seq(1,10))
        
        N_metrics
    }, rownames = TRUE)
    
    #Generates a list of all the artist's albums
    output$discography <- renderTable({
        req(input$picker != '')
        
        data <- get_artist_audio_features(input$picker)
        data$album_name <- as.factor(data$album_name)
        data$album_release_year <- as.factor(data$album_release_year)
        str(data$album_name)
        albums <- data %>%
            group_by(album_name, album_release_year)%>%
            summarise(Songs = n())
        
        albums <- as.matrix(albums)
        
        colnames(albums) <- c("Album Name", "Release Year", "Song Count")
        row.names(albums) <- c (seq(1:nrow(albums)))
        albums
    }, rownames = TRUE)
    
    #Generates a list of artists related to the selected artist
    output$relatedartists <- renderTable({
        req(input$picker != '')

        data <- get_artist_audio_features(input$picker)
        related <- get_related_artists(data$artist_id[1])
        related <- as.matrix(related$name)
        colnames(related) <- c("Artist Name")
        row.names(related) <- c (seq(1:nrow(related)))
        related
    }, rownames = TRUE)
    
    #Generates a joy plot for the valence levels of the selected artists albums   
    output$joy <- renderPlot({
        req(input$picker != '')
        
        data <- get_artist_audio_features(input$picker)
        p <- ggplot(data, aes(x = valence, y = album_name, fill = album_name)) + 
            geom_joy() + 
            theme_joy() +
            theme(legend.position = "none")+
            xlab("Valence") +
            ylab("Album Name") +
            ggtitle("Valence by album")
        p
    })  
    
}

# Run the application 
shinyApp(ui = ui, server = server)
